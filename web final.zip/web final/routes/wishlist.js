const express = require('express');
const router = express.Router();
const Wishlist = require('../models/wishlist');
const Product = require('../models/product');

// Add to Wishlist
router.post('/add-to-wishlist/:productId', async (req, res) => {
  if (!req.session.user) {
    return res.status(401).json({ message: 'Please log in to add items to your wishlist.' });
  }

  const userId = req.session.user._id;
  const productId = req.params.productId;

  try {
    // Check if product is already in wishlist
    const existingWishlistItem = await Wishlist.findOne({ userId, productId });
    if (existingWishlistItem) {
      return res.status(400).json({ message: 'This product is already in your wishlist.' });
    }

    // Add product to wishlist
    const newWishlistItem = new Wishlist({ userId, productId });
    await newWishlistItem.save();

    res.status(200).json({ message: 'Product added to wishlist.' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error adding product to wishlist.' });
  }
});

// View Wishlist
router.get('/wishlist', async (req, res) => {
  if (!req.session.user) {
    return res.redirect('/login');
  }

  const userId = req.session.user._id;

  try {
    const wishlistItems = await Wishlist.find({ userId }).populate('productId');
    res.render('wishlist', { wishlistItems });
  } catch (err) {
    console.error(err);
    res.status(500).send('Error fetching wishlist items');
  }
});

module.exports = router;
